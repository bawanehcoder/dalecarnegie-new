<th <?php echo e($attributes); ?>>
    <?php echo e($slot); ?>

</th>
<?php /**PATH D:\dalecarnegie\vendor\eightynine\filament-reports\src\/../resources/views/components/table/head-cell.blade.php ENDPATH**/ ?>