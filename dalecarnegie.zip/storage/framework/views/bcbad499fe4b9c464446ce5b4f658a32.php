<?php
    $size = $getSize();
?>
<?php if (isset($component)) { $__componentOriginalda07b93eddb9ed908ec1ed409a4f2aa3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalda07b93eddb9ed908ec1ed409a4f2aa3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament-reports::components.table.index','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament-reports::table.index'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php if (isset($component)) { $__componentOriginal8abdc3f5a9c9dd8c9f3c23712655d2f2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8abdc3f5a9c9dd8c9f3c23712655d2f2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament-reports::components.table.row','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament-reports::table.row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <?php if (isset($component)) { $__componentOriginalca1389cfce311448447d0904f7976dab = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalca1389cfce311448447d0904f7976dab = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament-reports::components.table.cell','data' => ['class' => 'pad','style' => 'padding-top:'.e($size).';']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament-reports::table.cell'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'pad','style' => 'padding-top:'.e($size).';']); ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalca1389cfce311448447d0904f7976dab)): ?>
<?php $attributes = $__attributesOriginalca1389cfce311448447d0904f7976dab; ?>
<?php unset($__attributesOriginalca1389cfce311448447d0904f7976dab); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalca1389cfce311448447d0904f7976dab)): ?>
<?php $component = $__componentOriginalca1389cfce311448447d0904f7976dab; ?>
<?php unset($__componentOriginalca1389cfce311448447d0904f7976dab); ?>
<?php endif; ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8abdc3f5a9c9dd8c9f3c23712655d2f2)): ?>
<?php $attributes = $__attributesOriginal8abdc3f5a9c9dd8c9f3c23712655d2f2; ?>
<?php unset($__attributesOriginal8abdc3f5a9c9dd8c9f3c23712655d2f2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8abdc3f5a9c9dd8c9f3c23712655d2f2)): ?>
<?php $component = $__componentOriginal8abdc3f5a9c9dd8c9f3c23712655d2f2; ?>
<?php unset($__componentOriginal8abdc3f5a9c9dd8c9f3c23712655d2f2); ?>
<?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalda07b93eddb9ed908ec1ed409a4f2aa3)): ?>
<?php $attributes = $__attributesOriginalda07b93eddb9ed908ec1ed409a4f2aa3; ?>
<?php unset($__attributesOriginalda07b93eddb9ed908ec1ed409a4f2aa3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalda07b93eddb9ed908ec1ed409a4f2aa3)): ?>
<?php $component = $__componentOriginalda07b93eddb9ed908ec1ed409a4f2aa3; ?>
<?php unset($__componentOriginalda07b93eddb9ed908ec1ed409a4f2aa3); ?>
<?php endif; ?>
<?php /**PATH D:\dalecarnegie\vendor\eightynine\filament-reports\src\/../resources/views/components/vertical-space.blade.php ENDPATH**/ ?>