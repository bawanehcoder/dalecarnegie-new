<?php

namespace App\Filament\Resources\SupervisorResource\Pages;

use App\Filament\Resources\SupervisorResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateSupervisor extends CreateRecord
{
    protected static string $resource = SupervisorResource::class;
}
