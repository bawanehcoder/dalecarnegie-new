<tfoot <?php echo e($attributes); ?>>
    <?php echo e($slot); ?>

</tfoot>
<?php /**PATH D:\dalecarnegie\vendor\eightynine\filament-reports\src\/../resources/views/components/table/foot.blade.php ENDPATH**/ ?>