<td <?php echo e($attributes); ?>>
    <?php echo e($slot); ?>

</td>
<?php /**PATH D:\dalecarnegie\vendor\eightynine\filament-reports\src\/../resources/views/components/table/cell.blade.php ENDPATH**/ ?>