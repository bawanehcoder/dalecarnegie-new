<div class="checkout-box">

    <div class="single-method form-check">
        <input class="form-check-input" type="checkbox" id="terms_conditions">
        <label class="form-check-label" for="terms_conditions">@langucw('i have read the terms and conditions and agree to them')</label>
    </div>
    <button class="btn btn-dark btn-primary-hover rounded-0 mt-6" onclick="CompleteReques()">@langucw('complete the request')</button>

</div>
