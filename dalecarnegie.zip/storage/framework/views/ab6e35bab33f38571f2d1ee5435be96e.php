<tbody <?php echo e($attributes); ?>>
    <?php echo e($slot); ?>

</tbody>
<?php /**PATH D:\dalecarnegie\vendor\eightynine\filament-reports\src\/../resources/views/components/table/body.blade.php ENDPATH**/ ?>