<!--[if BLOCK]><![endif]--><?php $__currentLoopData = $getComponents(withHidden: true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reportComponent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo e($reportComponent); ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
<?php /**PATH D:\dalecarnegie\vendor\eightynine\filament-reports\src\/../resources/views/component-container.blade.php ENDPATH**/ ?>