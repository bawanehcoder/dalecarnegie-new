<thead <?php echo e($attributes); ?>>
    <?php echo e($slot); ?>

</thead>
<?php /**PATH D:\dalecarnegie\vendor\eightynine\filament-reports\src\/../resources/views/components/table/head.blade.php ENDPATH**/ ?>