<tr <?php echo e($attributes); ?>>
    <?php echo e($slot); ?>

</tr>
<?php /**PATH D:\dalecarnegie\vendor\eightynine\filament-reports\src\/../resources/views/components/table/row.blade.php ENDPATH**/ ?>