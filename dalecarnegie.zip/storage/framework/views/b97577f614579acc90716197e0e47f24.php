<table
    <?php echo e($attributes); ?>>
    <?php echo e($slot); ?>

</table>
<?php /**PATH D:\dalecarnegie\vendor\eightynine\filament-reports\src\/../resources/views/components/table/index.blade.php ENDPATH**/ ?>